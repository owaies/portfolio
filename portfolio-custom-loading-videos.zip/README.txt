# Portfolio Custom Loading Videos

Copy the six files in `public/loading/` into the portfolio repository at:

public/loading/

Official mapping:
- Organic Intelligence desktop: organic-intelligence-desktop.mp4
- Organic Intelligence mobile: organic-intelligence-mobile.mp4
- Digital Architecture desktop: digital-architecture-desktop.mp4
- Digital Architecture mobile: digital-architecture-mobile.mp4
- Neural Interface desktop: neural-interface-desktop.mp4
- Neural Interface mobile: neural-interface-mobile.mp4

The extra uploaded video `1000335317.mp4` is not included because it is a 2.17s mobile browser/screen-recording asset, not one of the six 6-second loading animations.
